DROP PROCEDURE IF EXISTS query_credit;
CREATE PROCEDURE query_credit() SELECT * FROM t_credit;