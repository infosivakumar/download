TRUNCATE TABLE batch_step_execution_context;
TRUNCATE TABLE batch_step_execution;
TRUNCATE TABLE batch_job_execution_params;
TRUNCATE TABLE batch_job_execution_context;
TRUNCATE TABLE batch_job_execution;
TRUNCATE TABLE batch_job_instance;